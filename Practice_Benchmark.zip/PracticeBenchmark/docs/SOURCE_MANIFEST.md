# Source Manifest

Downloaded on 2026-05-19.

## Sources Downloaded

1. P-N-Suganthan/2020-RW-Constrained-Optimisation
   - URL: https://github.com/P-N-Suganthan/2020-RW-Constrained-Optimisation
   - Archive: `PracticeBenchmark/official_archive/2020-RW-Constrained-Optimisation.zip`
   - SHA256: `045743FA853040BC64BB5F674D371028F7E7958A2DA753D7C385F1F69745A20C`
   - Extracted MATLAB source: `PracticeBenchmark/official_source/2020-RW-Constrained-Optimisation-master/SOFTWARE/Software/CEC2020`
   - Inner source ZIP SHA256: `AD5F679D6CF46E690FCE27F0E5CD79FDCEB3AA4323948ADB1B65E4863ED9B825`
   - MATLAB wrappers generated: 57.
   - Validation: all 57 wrappers were called in MATLAB R2022a at the midpoint of their official bounds and returned without wrapper-level failure.

2. ENOPPY
   - URL: https://github.com/thieu1995/enoppy
   - Archive: `PracticeBenchmark/official_archive/enoppy-main.zip`
   - SHA256: `DAF4A0D7990AAB9FD160173AEEE2E44A21D1B2776E62B64FD055D097F3AE5A2B`
   - Extracted Python source: `PracticeBenchmark/official_source/enoppy-main`
   - MATLAB wrappers generated: 24.
   - Validation: the 24 wrapped Python classes evaluated directly with the local bundled Python and NumPy. MATLAB execution of ENOPPY wrappers was not verified because MATLAB R2022a rejected the available Python 3.12 runtime.
   - Not wrapped: `moeosma_2023.MultiProductBatchPlantProblem`; the downloaded upstream class raised `IndexError: index 9 is out of bounds for axis 0 with size 9` during direct evaluation. The source is preserved, but no runnable MATLAB wrapper was generated for it.

3. kabeersanan/sinh_cosh-Optimizer
   - URL: https://github.com/kabeersanan/sinh_cosh-Optimizer
   - Archive: `PracticeBenchmark/official_archive/sinh_cosh-Optimizer-main.zip`
   - SHA256: `46D7887F0F2BEA9A8A1144CE4D87D2F5C4BBA2F22CEFBBC0DFD9A1D49F5F9894`
   - Extracted MATLAB source: `PracticeBenchmark/official_source/sinh_cosh-Optimizer-main/Func_eng.m`
   - MATLAB wrappers generated: 6.
   - Validation: all 6 wrappers were called in MATLAB R2022a at the midpoint of their source bounds.
   - Limitation: this is a secondary algorithm-repository source, not a competition official benchmark package. Its `Func_eng.m` returns a penalized objective value and does not expose separate raw constraints.

## Source Checked but Not Downloaded

MathWorks File Exchange entry "Social Network Search for solving engineering problems":

- URL: https://www.mathworks.com/matlabcentral/fileexchange/97577-social-network-search-for-solving-engineering-problems
- Status: the page was reachable and describes MATLAB code for several engineering optimization problems, but the download button requires MathWorks login. I did not bypass login or fabricate the files.

## Important Notes

- The wrapper files do not rewrite the official benchmark formulas. They delegate to downloaded source files.
- CEC2020 wrappers reset the official `initial_flag` when switching problem IDs, because the official `cec20_func.m` uses persistent data. This avoids cross-problem data reuse while preserving the original formulas.
- ENOPPY wrappers return raw objectives from `get_objs`, raw constraints from `get_cons`, and ENOPPY's default penalized value from `evaluate`.
- Secondary `PB_MATLAB6_*` wrappers return only the source `Func_eng.m` penalized objective value.
