# Common Engineering Benchmarks Found

The following real-world engineering problems are commonly used in continuous metaheuristic and constrained optimization papers and were found in the downloaded sources.

## Mechanical Design

- Tension/compression spring design
- Welded beam design
- Pressure vessel design
- Speed reducer design
- Three-bar truss design
- Multiple disk clutch brake design
- Planetary gear train design
- Step-cone pulley design
- Robot gripper design
- Hydro-static thrust bearing design
- Four-stage gear box design
- 10-bar truss design
- Rolling element bearing design
- Gas transmission compressor design
- Gear train design
- Cantilever beam design
- I-beam design
- Tubular column design
- Piston lever design
- Corrugated bulkhead design
- Reinforced concrete beam design
- Car side impact design
- Vibrating platform design
- Bulk carrier design

## Chemical and Process Design

- Heat exchanger network design
- Alkylation unit operation
- Reactor network design
- Haverly pooling problem
- Blending-pooling-separation problem
- Propane/isobutane/n-butane nonsharp separation
- Process synthesis
- Process synthesis and design
- Process flow sheeting
- Two-reactor problem
- Multi-product batch plant
- Industrial refrigeration system design

## Power and Energy Systems

- Distributed generation sizing
- Reactive power support and phase balancing
- Optimal power flow
- Microgrid power flow
- Droop-controller setting
- Wind farm layout
- SOPWM inverter design

## Agriculture and Resource Problems

- Livestock feed ration optimization
- Water resource management

