# PracticeBenchmark

This folder keeps downloaded, traceable engineering benchmark sources and MATLAB entry files.

## Quick Start in MATLAB

```matlab
addpath('E:\论文草稿\zoo_LLM_cec\PracticeBenchmark');
PracticeBenchmark_addpath;

info = PB_RWCO20_F17_TensionCompressionSpringDesignCase1();
x = (info.lb + info.ub) ./ 2;
[f, g, h] = PB_RWCO20_F17_TensionCompressionSpringDesignCase1(x);
```

For the official MATLAB CEC2020 real-world constrained suite:

- `f` is the objective value.
- `g` is the inequality-constraint vector.
- `h` is the equality-constraint vector.
- Calling a wrapper with no input returns `info` with bounds, dimension, and source metadata.

ENOPPY wrappers are also present, for example:

```matlab
[f, cons, penalty, info] = PB_EN_PDO22_PressureVessel([1 1 50 100]);
```

These ENOPPY wrappers call the downloaded Python source through MATLAB's Python interface. They require a MATLAB-supported Python version with `numpy`. On this machine, MATLAB R2022a rejected the available Python 3.12, so ENOPPY MATLAB execution was not verified here.

Six secondary pure-MATLAB wrappers are also included from a downloaded `Func_eng.m` source:

```matlab
info = PB_MATLAB6_PressureVesselDesign();
value = PB_MATLAB6_PressureVesselDesign((info.lb + info.ub) ./ 2);
```

These six return the source author's penalized objective value only; that source does not expose separate raw constraints.

## Contents

- `official_archive/`: downloaded source archives.
- `official_source/`: extracted original source code.
- `matlab_wrappers/`: one MATLAB callable wrapper per benchmark problem where a working source interface could be confirmed.
- `docs/WRAPPER_INDEX.csv`: wrapper index with source and status.
- `docs/SOURCE_MANIFEST.md`: source URLs, hashes, and limitations.
