function PracticeBenchmark_addpath()
%PRACTICEBENCHMARK_ADDPATH Add benchmark wrappers and downloaded MATLAB source.

baseDir = fileparts(mfilename('fullpath'));
addpath(fullfile(baseDir, 'matlab_wrappers'));
addpath(fullfile(baseDir, 'official_source', '2020-RW-Constrained-Optimisation-master', ...
    'SOFTWARE', 'Software', 'CEC2020'));
end
