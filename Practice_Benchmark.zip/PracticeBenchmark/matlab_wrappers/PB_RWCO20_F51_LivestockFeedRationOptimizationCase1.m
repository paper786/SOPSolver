function [f, g, h, info] = PB_RWCO20_F51_LivestockFeedRationOptimizationCase1(x)
%PB_RWCO20_F51_LivestockFeedRationOptimizationCase1 Livestock Feed Ration Optimization (case 1)
%   [f,g,h,info] = PB_RWCO20_F51_LivestockFeedRationOptimizationCase1(x) evaluates one CEC2020 real-world
%   constrained benchmark problem. x can be a row vector or a population
%   matrix. f is the objective value, g inequality constraints, and h
%   equality constraints. With no input, the function returns the metadata
%   struct as the first output.

prob_k = 51;
info = PB_cec2020_info(prob_k);
if nargin == 0
    f = info;
    g = [];
    h = [];
    return;
end
[f, g, h] = PB_cec2020_eval(x, prob_k);
end
