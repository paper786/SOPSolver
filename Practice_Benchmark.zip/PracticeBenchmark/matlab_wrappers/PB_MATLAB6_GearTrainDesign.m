function [value, info] = PB_MATLAB6_GearTrainDesign(x)
%PB_MATLAB6_GEARTRAINDESIGN Gear train design.
if nargin == 0
    x = [];
end
[value, info] = PB_scho_func_eng_eval(x, 'GearTrainDesign', 'Gear train design');
end
