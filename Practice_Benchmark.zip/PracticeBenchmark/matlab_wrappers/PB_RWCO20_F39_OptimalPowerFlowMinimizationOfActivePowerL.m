function [f, g, h, info] = PB_RWCO20_F39_OptimalPowerFlowMinimizationOfActivePowerL(x)
%PB_RWCO20_F39_OptimalPowerFlowMinimizationOfActivePowerL Optimal Power flow (Minimization of Active Power Loss and Fuel Cost)
%   [f,g,h,info] = PB_RWCO20_F39_OptimalPowerFlowMinimizationOfActivePowerL(x) evaluates one CEC2020 real-world
%   constrained benchmark problem. x can be a row vector or a population
%   matrix. f is the objective value, g inequality constraints, and h
%   equality constraints. With no input, the function returns the metadata
%   struct as the first output.

prob_k = 39;
info = PB_cec2020_info(prob_k);
if nargin == 0
    f = info;
    g = [];
    h = [];
    return;
end
[f, g, h] = PB_cec2020_eval(x, prob_k);
end
