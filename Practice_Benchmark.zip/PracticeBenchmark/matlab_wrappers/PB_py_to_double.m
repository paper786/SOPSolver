function out = PB_py_to_double(value)
%PB_PY_TO_DOUBLE Convert Python scalars/lists/numpy arrays to MATLAB double.

if isnumeric(value)
    out = double(value);
    return;
end
cls = class(value);
if contains(cls, 'py.numpy.ndarray')
    value = value.tolist();
end
if isa(value, 'py.list') || isa(value, 'py.tuple')
    c = cell(value);
    out = zeros(size(c));
    for k = 1:numel(c)
        out(k) = PB_py_to_double(c{k});
    end
else
    out = double(value);
end
end
