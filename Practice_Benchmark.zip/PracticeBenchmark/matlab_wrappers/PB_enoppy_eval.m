function [objs, cons, penalty, info] = PB_enoppy_eval(x, moduleName, className, displayName)
%PB_ENOPPY_EVAL Evaluate a downloaded ENOPPY engineering problem class.
%   objs are raw objective values from get_objs, cons are raw constraints
%   from get_cons, and penalty is ENOPPY's evaluate output using its default
%   penalty function.

sourceDir = PB_enoppy_setup();
if ismatrix(x) && ~isvector(x)
    error('PracticeBenchmark:VectorOnly', 'ENOPPY wrappers accept one decision vector at a time.');
end
x = double(x(:)');
np = py.importlib.import_module('numpy');
mod = py.importlib.import_module(['enoppy.paper_based.' moduleName]);
cls = py.getattr(mod, className);
problem = cls();
xPy = np.array(x);
try
    xPy = problem.amend_position(xPy, problem.lb, problem.ub);
catch
    % Some ENOPPY classes inherit the no-op base amend_position.
end
objs = PB_py_to_double(problem.get_objs(xPy));
cons = PB_py_to_double(problem.get_cons(xPy));
penalty = PB_py_to_double(problem.evaluate(xPy));
info = struct();
info.source = 'ENOPPY downloaded source';
info.source_url = 'https://github.com/thieu1995/enoppy';
info.local_source = sourceDir;
info.module = moduleName;
info.class = className;
info.name = displayName;
info.n = double(problem.n_dims);
info.lb = PB_py_to_double(problem.lb);
info.ub = PB_py_to_double(problem.ub);
info.n_objs = double(problem.n_objs);
info.n_cons = double(problem.n_cons);
end
