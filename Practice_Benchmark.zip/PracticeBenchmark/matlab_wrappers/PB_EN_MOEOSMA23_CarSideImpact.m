function [f, cons, penalty, info] = PB_EN_MOEOSMA23_CarSideImpact(x)
%PB_EN_MOEOSMA23_CarSideImpact Car side impact design problem
%   [f,cons,penalty,info] = PB_EN_MOEOSMA23_CarSideImpact(x) calls the downloaded ENOPPY
%   Python implementation. f is the raw objective vector from get_objs,
%   cons is the raw constraint vector from get_cons, and penalty is ENOPPY's
%   default penalized evaluate output. With no input, the function returns
%   the metadata struct as the first output.

moduleName = 'moeosma_2023';
className = 'CarSideImpactProblem';
displayName = 'Car side impact design problem';
if nargin == 0
    sourceDir = PB_enoppy_setup();
    modObj = py.importlib.import_module(['enoppy.paper_based.' moduleName]);
    clsObj = py.getattr(modObj, className);
    problem = clsObj();
    info = struct();
    info.source = 'ENOPPY downloaded source';
    info.source_url = 'https://github.com/thieu1995/enoppy';
    info.local_source = sourceDir;
    info.module = moduleName;
    info.class = className;
    info.name = displayName;
    info.n = double(problem.n_dims);
    info.lb = PB_py_to_double(problem.lb);
    info.ub = PB_py_to_double(problem.ub);
    info.n_objs = double(problem.n_objs);
    info.n_cons = double(problem.n_cons);
    f = info;
    cons = [];
    penalty = [];
    return;
end
[f, cons, penalty, info] = PB_enoppy_eval(x, moduleName, className, displayName);
end
