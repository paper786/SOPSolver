function [value, info] = PB_MATLAB6_ThreeBarTruss(x)
%PB_MATLAB6_THREEBARTRUSS Three-bar truss design.
if nargin == 0
    x = [];
end
[value, info] = PB_scho_func_eng_eval(x, 'ThreeBarTruss', 'Three-bar truss design');
end
