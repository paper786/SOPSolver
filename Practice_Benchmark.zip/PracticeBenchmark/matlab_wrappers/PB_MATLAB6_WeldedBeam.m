function [value, info] = PB_MATLAB6_WeldedBeam(x)
%PB_MATLAB6_WELDEDBEAM Welded beam design.
if nargin == 0
    x = [];
end
[value, info] = PB_scho_func_eng_eval(x, 'WeldedBeam', 'Welded beam design');
end
