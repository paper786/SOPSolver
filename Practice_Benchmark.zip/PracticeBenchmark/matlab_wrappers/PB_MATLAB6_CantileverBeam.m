function [value, info] = PB_MATLAB6_CantileverBeam(x)
%PB_MATLAB6_CANTILEVERBEAM Cantilever beam design.
if nargin == 0
    x = [];
end
[value, info] = PB_scho_func_eng_eval(x, 'CantileverBeam', 'Cantilever beam design');
end
