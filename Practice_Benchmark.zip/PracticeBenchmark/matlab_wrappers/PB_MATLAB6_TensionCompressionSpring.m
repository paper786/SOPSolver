function [value, info] = PB_MATLAB6_TensionCompressionSpring(x)
%PB_MATLAB6_TENSIONCOMPRESSIONSPRING Tension/compression spring design.
%   The downloaded source names this case StringDesign.
if nargin == 0
    x = [];
end
[value, info] = PB_scho_func_eng_eval(x, 'StringDesign', 'Tension/compression spring design');
end
