function sourceDir = PB_enoppy_setup()
%PB_ENOPPY_SETUP Add the downloaded ENOPPY source tree to MATLAB Python path.
%   ENOPPY itself is Python source. These MATLAB wrappers call that source
%   through MATLAB's Python interface instead of rewriting the benchmark formulas.

sourceDir = fullfile(fileparts(fileparts(mfilename('fullpath'))), ...
    'official_source', 'enoppy-main');
if ~exist(fullfile(sourceDir, 'enoppy', 'engineer.py'), 'file')
    error('PracticeBenchmark:MissingSource', 'Cannot find ENOPPY source at %s', sourceDir);
end
p = py.sys.path;
if count(p, sourceDir) == 0
    insert(p, int32(0), sourceDir);
end
end
