function [value, info] = PB_MATLAB6_PressureVesselDesign(x)
%PB_MATLAB6_PRESSUREVESSELDESIGN Pressure Vessel Design.
if nargin == 0
    x = [];
end
[value, info] = PB_scho_func_eng_eval(x, 'PressureVesselDesign', 'Pressure Vessel Design');
end
