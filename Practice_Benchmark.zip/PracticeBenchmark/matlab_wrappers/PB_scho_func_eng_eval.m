function [value, info] = PB_scho_func_eng_eval(x, problemKey, displayName)
%PB_SCHO_FUNC_ENG_EVAL Evaluate a secondary MATLAB engineering benchmark.
%   This helper delegates to the downloaded Func_eng.m file from the
%   kabeersanan/sinh_cosh-Optimizer repository. That source returns the
%   author's penalized objective value, not separate raw constraints.

sourceDir = fullfile(fileparts(fileparts(mfilename('fullpath'))), ...
    'official_source', 'sinh_cosh-Optimizer-main');
if ~exist(fullfile(sourceDir, 'Func_eng.m'), 'file')
    error('PracticeBenchmark:MissingSource', 'Cannot find Func_eng.m at %s', sourceDir);
end
addpath(sourceDir);
[lb, ub, dim, funcHandle] = Func_eng(problemKey);
info = struct();
info.source = 'kabeersanan/sinh_cosh-Optimizer Func_eng.m';
info.source_url = 'https://github.com/kabeersanan/sinh_cosh-Optimizer';
info.problem_key = problemKey;
info.name = displayName;
info.n = dim;
info.lb = lb;
info.ub = ub;
info.output = 'penalized objective value from source Func_eng.m';
if nargin < 1 || isempty(x)
    value = info;
    return;
end
if isvector(x)
    x = x(:)';
end
value = funcHandle(x);
end
