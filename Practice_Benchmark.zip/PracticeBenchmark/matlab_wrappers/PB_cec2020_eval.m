function [f, g, h] = PB_cec2020_eval(x, prob_k)
%PB_CEC2020_EVAL Evaluate a CEC2020 real-world constrained problem.
%   Core formulas are not rewritten here. This helper delegates to the
%   downloaded official MATLAB source cec20_func.m from P-N-Suganthan's
%   2020-RW-Constrained-Optimisation repository.

sourceDir = fullfile(fileparts(fileparts(mfilename('fullpath'))), ...
    'official_source', '2020-RW-Constrained-Optimisation-master', ...
    'SOFTWARE', 'Software', 'CEC2020');
if ~exist(fullfile(sourceDir, 'cec20_func.m'), 'file')
    error('PracticeBenchmark:MissingSource', 'Cannot find official cec20_func.m at %s', sourceDir);
end
addpath(sourceDir);
if isvector(x)
    x = x(:)';
end
oldDir = pwd;
cleanupObj = onCleanup(@() cd(oldDir));
cd(sourceDir);
global initial_flag
persistent last_prob_k
if isempty(last_prob_k) || last_prob_k ~= prob_k
    initial_flag = 0;
end
[f, g, h] = cec20_func(x, prob_k);
last_prob_k = prob_k;
end
